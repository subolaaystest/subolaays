module.exports = {
    options: {
      pretty: true,
      data: {
        require: require
      }
    }
  };