<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class FaqTranslationsTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('faq_translations')->delete();
        
        
        
    }
}