<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class StorageTypeTranslationsTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('storage_type_translations')->delete();
        
        
        
    }
}